codeunit 70010 "DFI Costing To Entry Total"
{
    procedure GenerateCostingFromStyleItem(StyleItemNo: Code[20])
    var
        StyleMaster: Record "Style Master";
    begin
        StyleMaster.Reset();
        StyleMaster.SetRange("Item No.", StyleItemNo);
        if not StyleMaster.FindFirst() then
            Error('Style Master not found for Item No. %1.', StyleItemNo);

        GenerateCosting(StyleMaster);
    end;

    procedure GenerateCosting(var StyleMaster: Record "Style Master")
    begin
        DeleteExistingLines(StyleMaster."Item No.");

        InsertWarpWeftCost(StyleMaster);
        // InsertDyeingCost(StyleMaster);
        // InsertSizingCost(StyleMaster);
        // InsertFinishingCost(StyleMaster);
        // InsertPackingCost(StyleMaster);
        // InsertRoutingCost(StyleMaster);
    end;

    local procedure DeleteExistingLines(StyleItemNo: Code[20])
    var
        EntryTotal: Record "DFI ILE Entry Total";
    begin
        EntryTotal.Reset();
        EntryTotal.SetRange("Costing Type", EntryTotal."Costing Type"::Standard);
        EntryTotal.SetRange("Total Entry Type", EntryTotal."Total Entry Type"::Consumption);
        // EntryTotal.SetRange(Type, EntryTotal.Type::Item);
        // EntryTotal.SetRange(Value, StyleItemNo);
        // EntryTotal.SetRange("Style Item No.", StyleItemNo);
        EntryTotal.DeleteAll();
    end;

    local procedure InsertWarpWeftCost(var StyleMaster: Record "Style Master")
    var
        StyleMixingLine: Record "Style Mixing Line";
    begin
        StyleMixingLine.Reset();
        StyleMixingLine.SetRange("No.", StyleMaster."No.");
        if StyleMixingLine.FindSet() then
            repeat
                InsertYarnCost(StyleMaster, 'WARP', StyleMixingLine."Warp 1", StyleMixingLine."Warp Ratio 1", StyleMixingLine);
                InsertYarnCost(StyleMaster, 'WARP', StyleMixingLine."Warp 2", StyleMixingLine."Warp Ratio 2", StyleMixingLine);
                InsertYarnCost(StyleMaster, 'WARP', StyleMixingLine."Warp 3", StyleMixingLine."Warp Ratio 3", StyleMixingLine);
                InsertYarnCost(StyleMaster, 'WARP', StyleMixingLine."Warp 4", StyleMixingLine."Warp Ratio 4", StyleMixingLine);

                InsertYarnCost(StyleMaster, 'WEFT', StyleMixingLine."Weft 1", StyleMixingLine."Weft Ratio 1", StyleMixingLine);
                InsertYarnCost(StyleMaster, 'WEFT', StyleMixingLine."Weft 2", StyleMixingLine."Weft Ratio 2", StyleMixingLine);
                InsertYarnCost(StyleMaster, 'WEFT', StyleMixingLine."Weft 3", StyleMixingLine."Weft Ratio 3", StyleMixingLine);
                InsertYarnCost(StyleMaster, 'WEFT', StyleMixingLine."Weft 4", StyleMixingLine."Weft Ratio 4", StyleMixingLine);
            until StyleMixingLine.Next() = 0;
    end;

    local procedure InsertYarnCost(var StyleMaster: Record "Style Master"; ProcessType: Code[100]; YarnNo: Code[20]; Ratio: Decimal; StyleMixingLine: Record "Style Mixing Line")
    var
        YarnMaster: Record "Yarn Master";
        ItemRec: Record Item;
        Qty: Decimal;
        UnitCost: Decimal;
        Amount: Decimal;
        GreyFabric: Decimal;
    begin
        if YarnNo = '' then
            exit;

        if not YarnMaster.Get(YarnNo) then
            exit;

        if not ItemRec.Get(YarnMaster."Item No.") then
            exit;

        if YarnMaster."Yarn Resultant ne Count" = 0 then
            exit;

        GreyFabric := 1;


        // if ItemRec.Get(YarnMaster."Item No.") then
        //     if YarnMaster."Yarn Resultant ne Count" <> 0 then begin
        //         if GreyFabric = 0 then begin
        //             UnitCost := Round(Item."Unit Cost" * ((StyleMaster."Total Ends" / 1693 / YarnMaster."Yarn Resultant ne Count") * 1), 0.01);
        //             WarpWeight1 := Round("Style Mixing Line"."Warp Ratio 1" * ((StyleMaster."Total Ends" / 1693 / YarnMaster."Yarn Resultant ne Count") * 1), 0.001);
        //         end
        //         else begin
        //             WarpUnitCost1 := Round(Item."Unit Cost" * ((StyleMaster."Total Ends" / 1693 / YarnMaster."Yarn Resultant ne Count") * GreyFabric), 0.01);
        //             WarpWeight1 := Round("Style Mixing Line"."Warp Ratio 1" * ((StyleMaster."Total Ends" / 1693 / YarnMaster."Yarn Resultant ne Count") * GreyFabric), 0.001);
        //         end;
        //         Warp1YarnNeCount := YarnMaster."Yarn Resultant ne Count";
        //         WarpNotZero += 1;
        //         //  AddRoutingCodes(Item."Routing No.");
        //     end;

        Qty := Round(Ratio * ((StyleMaster."Total Ends" / 1693 / YarnMaster."Yarn Resultant ne Count") * GreyFabric), 0.001);
        UnitCost := ItemRec."Unit Cost";
        Amount := Round(UnitCost * Qty, 0.01);

        InsertEntryTotal(
    StyleMaster."No.",
    StyleMaster."Item No.",
    ItemRec."No.",
    ProcessType,
    Qty,
    Amount,
    UnitCost);
    end;
    /*
        local procedure InsertDyeingCost(var StyleMaster: Record "Style Master")
        var
            ChemLine: Record "Standard Chemical Master Line";
            ItemRec: Record Item;
            Qty: Decimal;
            UnitCost: Decimal;
            Amount: Decimal;
        begin
            ChemLine.Reset();
            ChemLine.SetRange("Quality No.", StyleMaster."Quality No.");
            ChemLine.SetRange("Color Type", StyleMaster."Color Type");
            ChemLine.SetRange("Color Code", StyleMaster."Color Code");

            if ChemLine.FindSet() then
                repeat
                    if ItemRec.Get(ChemLine."Item Code") then begin
                        Qty := Round(ChemLine."Qty. Per Meter" / 1000, 0.00001);
                        UnitCost := ItemRec."Unit Cost";
                        Amount := Round(UnitCost * Qty, 0.01);

                        InsertEntryTotal(
                            ItemRec."No.",
                            'DYEING',
                            Qty,
                            Amount,
                            UnitCost);
                    end;
                until ChemLine.Next() = 0;
        end;

        local procedure InsertSizingCost(var StyleMaster: Record "Style Master")
        var
            ChemLine: Record "Standard Chemical Master Line";
            ItemRec: Record Item;
            Qty: Decimal;
            UnitCost: Decimal;
            Amount: Decimal;
        begin
            ChemLine.Reset();
            ChemLine.SetRange("Quality No.", StyleMaster."Quality No.");
            ChemLine.SetRange(Type, ChemLine.Type::Sizing);

            if ChemLine.FindSet() then
                repeat
                    if ItemRec.Get(ChemLine."Item Code") then begin
                        Qty := Round(ChemLine."Qty. Per Meter" / 1000, 0.00001);
                        UnitCost := ItemRec."Unit Cost";
                        Amount := Round(UnitCost * Qty, 0.01);

                        InsertEntryTotal(
                            ItemRec."No.",
                            'SIZING',
                            Qty,
                            Amount,
                            UnitCost);
                    end;
                until ChemLine.Next() = 0;
        end;

        local procedure InsertFinishingCost(var StyleMaster: Record "Style Master")
        var
            ProcessRouteDetails: Record "Process Route Details";
            ProdBOMHeader: Record "Production BOM Header";
            ProdBOMLine: Record "Production BOM Line";
            ItemRec: Record Item;
            VersionMgt: Codeunit VersionManagement;
            ActiveVersionCode: Code[20];
            Amount: Decimal;
        begin
            ProcessRouteDetails.Reset();
            ProcessRouteDetails.SetRange("Document No.", StyleMaster."No.");
            if ProcessRouteDetails.FindSet() then
                repeat
                    if ProdBOMHeader.Get(ProcessRouteDetails."BOM No.") then begin
                        ActiveVersionCode := VersionMgt.GetBOMVersion(ProdBOMHeader."No.", WorkDate(), true);

                        ProdBOMLine.Reset();
                        ProdBOMLine.SetRange("Production BOM No.", ProdBOMHeader."No.");
                        if ActiveVersionCode <> '' then
                            ProdBOMLine.SetRange("Version Code", ActiveVersionCode);

                        if ProdBOMLine.FindSet() then
                            repeat
                                if ItemRec.Get(ProdBOMLine."No.") then begin
                                    Amount := Round(ItemRec."Unit Cost" * ProdBOMLine."Quantity per", 0.01);

                                    InsertEntryTotal(
                                        ItemRec."No.",
                                        Format(ProcessRouteDetails."Prod.Type"),
                                        ProdBOMLine."Quantity per",
                                        Amount,
                                        ItemRec."Unit Cost");
                                end;
                            until ProdBOMLine.Next() = 0;
                    end;
                until ProcessRouteDetails.Next() = 0;
        end;

        local procedure InsertPackingCost(var StyleMaster: Record "Style Master")
        var
            ProductionBOMVersion: Record "Production BOM Version";
            ProductionBOMLine: Record "Production BOM Line";
            ItemRec: Record Item;
            BomVersionCode: Code[20];
            Amount: Decimal;
        begin
            BomVersionCode := GetBomVersion(StyleMaster);

            ProductionBOMVersion.Reset();
            ProductionBOMVersion.SetRange("Production BOM No.", 'BOM-0017');
            ProductionBOMVersion.SetRange("Version Code", BomVersionCode);

            if ProductionBOMVersion.FindFirst() then begin
                ProductionBOMLine.Reset();
                ProductionBOMLine.SetRange("Production BOM No.", 'BOM-0017');
                ProductionBOMLine.SetRange("Version Code", BomVersionCode);

                if ProductionBOMLine.FindSet() then
                    repeat
                        if ItemRec.Get(ProductionBOMLine."No.") then begin
                            Amount := Round(ItemRec."Unit Cost" * ProductionBOMLine."Quantity per", 0.01);

                            InsertEntryTotal(
                                ItemRec."No.",
                                'PACKING',
                                ProductionBOMLine."Quantity per",
                                Amount,
                                ItemRec."Unit Cost");
                        end;
                    until ProductionBOMLine.Next() = 0;
            end;
        end;

        local procedure InsertRoutingCost(var StyleMaster: Record "Style Master")
        var
            RoutingHeader: Record "Routing Header";
            RoutingLine: Record "Routing Line";
            RoutingCodeList: List of [Code[20]];
            ProcessRouteDetails: Record "Process Route Details";
            ItemRouting: Record Item;
            FilterString: Text;
            RoutingNo: Code[20];
        begin
            if ItemRouting.Get('SFG-00007') then
                AddRoutingCodes(RoutingCodeList, ItemRouting."Routing No.");

            if StyleMaster."Extra No of Ends" <> 0 then begin
                if ItemRouting.Get('SFG-01435') then
                    AddRoutingCodes(RoutingCodeList, ItemRouting."Routing No.");
            end else begin
                if ItemRouting.Get('SFG-00003') then
                    AddRoutingCodes(RoutingCodeList, ItemRouting."Routing No.");
                if ItemRouting.Get('SFG-00004') then
                    AddRoutingCodes(RoutingCodeList, ItemRouting."Routing No.");
                if ItemRouting.Get('SFG-00005') then
                    AddRoutingCodes(RoutingCodeList, ItemRouting."Routing No.");
                if ItemRouting.Get('SFG-00006') then
                    AddRoutingCodes(RoutingCodeList, ItemRouting."Routing No.");
            end;

            ProcessRouteDetails.Reset();
            ProcessRouteDetails.SetRange("Document No.", StyleMaster."No.");
            if ProcessRouteDetails.FindSet() then
                repeat
                    if ItemRouting.Get(ProcessRouteDetails."Item No.") then
                        AddRoutingCodes(RoutingCodeList, ItemRouting."Routing No.");
                until ProcessRouteDetails.Next() = 0;

            if ItemRouting.Get(StyleMaster."Item No.") then
                AddRoutingCodes(RoutingCodeList, ItemRouting."Routing No.");

            foreach RoutingNo in RoutingCodeList do begin
                if FilterString = '' then
                    FilterString := RoutingNo
                else
                    FilterString += '|' + RoutingNo;
            end;

            RoutingHeader.Reset();
            RoutingHeader.SetFilter("No.", FilterString);
            RoutingHeader.SetRange(Status, RoutingHeader.Status::Certified);

            if RoutingHeader.FindSet() then
                repeat
                    RoutingLine.Reset();
                    RoutingLine.SetRange("Routing No.", RoutingHeader."No.");
                    if RoutingHeader."Version Nos." <> '' then
                        RoutingLine.SetFilter("Version Code", RoutingHeader."Version Nos.");

                    if RoutingLine.FindSet() then
                        repeat
                            InsertEntryTotal(
                                '',
                                'ROUTING',
                                1,
                                RoutingLine."Unit Cost per",
                                RoutingLine."Unit Cost per");
                        until RoutingLine.Next() = 0;
                until RoutingHeader.Next() = 0;
        end;
        */

    local procedure InsertEntryTotal(StyleNo: Code[20]; StyleItemNo: Code[20]; ItemNo: Code[20]; ProcessType: Code[20]; Qty: Decimal; Amount: Decimal; UnitCost: Decimal)
    var
        EntryTotal: Record "DFI ILE Entry Total";
    begin
        EntryTotal.Reset();
        EntryTotal.SetRange("Costing Type", EntryTotal."Costing Type"::Standard);
        EntryTotal.SetRange("Total Entry Type", EntryTotal."Total Entry Type"::Consumption);
        EntryTotal.SetRange(Type, EntryTotal.Type::Item);
        EntryTotal.SetRange(Value, StyleItemNo);
        EntryTotal.SetRange("Style Item No.", StyleItemNo);
        EntryTotal.SetRange("Style No.", StyleNo);
        EntryTotal.SetRange("Process Type", ProcessType);
        EntryTotal.SetRange("Item No.", ItemNo);

        if EntryTotal.FindFirst() then begin
            EntryTotal."Total Quantity" += Qty;
            EntryTotal."Unit Cost" := UnitCost;
            EntryTotal."Total Amount" += Amount;
            EntryTotal.Modify();
        end else begin
            EntryTotal.Init();
            EntryTotal."Costing Type" := EntryTotal."Costing Type"::Standard;
            EntryTotal."Total Entry Type" := EntryTotal."Total Entry Type"::Consumption;
            EntryTotal.Type := EntryTotal.Type::Item;
            EntryTotal.Value := StyleItemNo;
            EntryTotal."Style Item No." := StyleItemNo;
            EntryTotal."Style No." := StyleNo;
            EntryTotal."Process Type" := ProcessType;
            EntryTotal."Item No." := ItemNo;
            EntryTotal."Total Quantity" := Qty;
            EntryTotal."Unit Cost" := UnitCost;
            EntryTotal."Total Amount" := Amount;
            EntryTotal.Insert();
        end;
    end;

    local procedure GetBomVersion(var StyleMaster: Record "Style Master"): Code[20]
    var
        ProductionBOMVersionRecord: Record "Production BOM Version";
    begin
        ProductionBOMVersionRecord.SetRange(Status, ProductionBOMVersionRecord.Status::Certified);
        ProductionBOMVersionRecord.SetRange("Production BOM No.", 'BOM-0017');
        ProductionBOMVersionRecord.SetFilter("Roll Width From", '<=%1', StyleMaster."Finished Width(cm)");
        ProductionBOMVersionRecord.SetFilter("Roll Width To", '>=%1', StyleMaster."Finished Width(cm)");
        if ProductionBOMVersionRecord.FindFirst() then
            exit(ProductionBOMVersionRecord."Version Code");
    end;

    local procedure AddRoutingCodes(var RoutingCodeList: List of [Code[20]]; RoutingNo: Code[20])
    begin
        if RoutingNo = '' then
            exit;

        if not RoutingCodeList.Contains(RoutingNo) then
            RoutingCodeList.Add(RoutingNo);
    end;
}
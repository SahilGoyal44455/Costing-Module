page 70001 "DFI ILE Lines Subpage"
{
    Caption = 'Output Item Ledger Entries';
    PageType = List;
    SourceTable = "Item Ledger Entry";
    SourceTableTemporary = true;
    ApplicationArea = All;
    UsageCategory = None;
    Editable = false;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;

    layout
    {
        area(Content)
        {
            group(FilterInfo)
            {
                Caption = 'Filters';

                field(Type; HeaderType)
                {
                    ApplicationArea = All;
                    Caption = 'Type';
                    Editable = false;
                    ToolTip = 'Specifies the header Type filter used to fetch output entries.';
                }
                field(Value; HeaderValue)
                {
                    ApplicationArea = All;
                    Caption = 'Value';
                    Editable = false;
                    ToolTip = 'Specifies the header Value filter used to fetch output entries.';
                }
            }

            repeater(Lines)
            {
                Editable = false;

                field("Entry No."; Rec."Entry No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the entry number of the item ledger entry.';
                }
                field("Posting Date"; Rec."Posting Date")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the posting date of the item ledger entry.';
                }
                field("Item No."; Rec."Item No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the item number of the item ledger entry.';
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the description of the item ledger entry.';
                }
                field("Item Category Code"; ItemCategoryCode)
                {
                    ApplicationArea = All;
                    Caption = 'Item Category Code';
                    ToolTip = 'Specifies the item category code from the related item card.';
                }
                field("Location Code"; Rec."Location Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the location code of the item ledger entry.';
                }
                field("Lot No."; Rec."Lot No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the lot number of the item ledger entry.';
                }
                field("Entry Type"; Rec."Entry Type")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the entry type of the item ledger entry. Only Output entries are loaded.';
                }
                field("Document Type"; Rec."Document Type")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the document type of the item ledger entry.';
                }
                field("Document No."; Rec."Document No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the document number of the item ledger entry.';
                }
                field("Planning No."; Rec."Planning No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the planning number of the output item ledger entry. Consumption entries are shown based on this value.';
                }
                field("Order No."; Rec."Order No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the order number of the item ledger entry.';
                }
                field(Quantity; Rec.Quantity)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the quantity of the item ledger entry.';
                }
                field("Remaining Quantity"; Rec."Remaining Quantity")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the remaining quantity of the item ledger entry.';
                }
                field("Actual Cost"; ActualCost)
                {
                    ApplicationArea = All;
                    Caption = 'Actual Cost';
                    AutoFormatType = 1;
                    ToolTip = 'Specifies the actual cost calculated from Value Entry for this item ledger entry.';
                }
                field("Unit Cost"; UnitCost)
                {
                    ApplicationArea = All;
                    Caption = 'Unit Cost';
                    AutoFormatType = 1;
                    ToolTip = 'Specifies the unit cost calculated as Actual Cost divided by Quantity.';
                }
            }
        }
    }

    trigger OnAfterGetRecord()
    begin
        SetItemCategoryCode();
        ActualCost := CalcActualCost(Rec."Entry No.");
        UnitCost := CalcUnitCost(ActualCost, Rec.Quantity);
    end;

    procedure LoadLines(FilterType: Option Blank,Item,"Item Category","MO wise"; FilterValue: Code[100]; DateFilter: Text[250])
    var
        ItemLedgerEntry: Record "Item Ledger Entry";
        Item: Record Item;
        PlanningNoList: List of [Code[20]];
        PlanningNo: Code[20];
    begin
        HeaderType := FilterType;
        HeaderValue := FilterValue;
        HeaderDateFilter := DateFilter;

        Rec.Reset();
        Rec.DeleteAll();

        if not HasValidFilter(FilterType, FilterValue, DateFilter) then begin
            CurrPage.Update(false);
            exit;
        end;

        ItemLedgerEntry.Reset();
        ItemLedgerEntry.SetRange("Entry Type", ItemLedgerEntry."Entry Type"::Output);

        if DateFilter <> '' then
            ItemLedgerEntry.SetFilter("Posting Date", DateFilter);

        case FilterType of
            FilterType::Blank:
                InsertItemLedgerEntries(ItemLedgerEntry);
            FilterType::Item:
                begin
                    if FilterValue = '' then begin
                        CurrPage.Update(false);
                        exit;
                    end;

                    ItemLedgerEntry.SetRange("Item No.", FilterValue);
                    InsertItemLedgerEntries(ItemLedgerEntry);
                end;
            FilterType::"Item Category":
                begin
                    if FilterValue = '' then begin
                        CurrPage.Update(false);
                        exit;
                    end;

                    Item.SetRange("Item Category Code", FilterValue);
                    if Item.FindSet() then
                        repeat
                            ItemLedgerEntry.SetRange("Item No.", Item."No.");
                            InsertItemLedgerEntries(ItemLedgerEntry);
                        until Item.Next() = 0;
                end;
            FilterType::"MO wise":
                begin
                    if FilterValue = '' then begin
                        CurrPage.Update(false);
                        exit;
                    end;

                    GetPlanningNosFromMO(FilterValue, PlanningNoList);
                    foreach PlanningNo in PlanningNoList do
                        InsertOutputEntriesByPlanningNo(PlanningNo, DateFilter);
                end;
        end;

        Rec.SetCurrentKey("Posting Date");
        CurrPage.Update(false);
    end;


    local procedure GetPlanningNosFromMO(MONo: Code[100]; var PlanningNoList: List of [Code[20]])
    var
        MOLine: Record "Mo Line";
    begin
        if MONo = '' then
            exit;

        MOLine.SetRange("Document No.", MONo);
        if MOLine.FindSet() then
            repeat
                if MOLine."Planning No" <> '' then
                    if not PlanningNoList.Contains(MOLine."Planning No") then
                        PlanningNoList.Add(MOLine."Planning No");
            until MOLine.Next() = 0;
    end;

    local procedure InsertOutputEntriesByPlanningNo(PlanningNo: Code[20]; DateFilter: Text[250])
    var
        OutputItemLedgerEntry: Record "Item Ledger Entry";
    begin
        OutputItemLedgerEntry.Reset();
        OutputItemLedgerEntry.SetRange("Entry Type", OutputItemLedgerEntry."Entry Type"::Output);
        OutputItemLedgerEntry.SetRange("Planning No.", PlanningNo);

        if DateFilter <> '' then
            OutputItemLedgerEntry.SetFilter("Posting Date", DateFilter);

        InsertItemLedgerEntries(OutputItemLedgerEntry);
    end;

    local procedure HasValidFilter(FilterType: Option Blank,Item,"Item Category","MO wise"; FilterValue: Code[100]; DateFilter: Text[250]): Boolean
    begin
        if DateFilter <> '' then
            exit(true);

        if (FilterType <> FilterType::Blank) and (FilterValue <> '') then
            exit(true);

        exit(false);
    end;

    local procedure InsertItemLedgerEntries(var ItemLedgerEntry: Record "Item Ledger Entry")
    begin
        if ItemLedgerEntry.FindSet() then
            repeat
                if not Rec.Get(ItemLedgerEntry."Entry No.") then begin
                    Rec.Init();
                    Rec := ItemLedgerEntry;
                    Rec.Insert();
                end;
            until ItemLedgerEntry.Next() = 0;
    end;

    local procedure SetItemCategoryCode()
    var
        Item: Record Item;
    begin
        Clear(ItemCategoryCode);

        if Rec."Item No." = '' then
            exit;

        if Item.Get(Rec."Item No.") then
            ItemCategoryCode := Item."Item Category Code";
    end;

    local procedure CalcActualCost(ItemLedgerEntryNo: Integer): Decimal
    var
        ValueEntry: Record "Value Entry";
        CostAmountActual: Decimal;
    begin
        Clear(CostAmountActual);

        if ItemLedgerEntryNo = 0 then
            exit(0);

        ValueEntry.SetRange("Item Ledger Entry No.", ItemLedgerEntryNo);
        if ValueEntry.FindSet() then
            repeat
                CostAmountActual += ValueEntry."Cost Amount (Actual)";
            until ValueEntry.Next() = 0;

        exit(CostAmountActual);
    end;

    local procedure CalcUnitCost(CostAmount: Decimal; Quantity: Decimal): Decimal
    begin
        if Quantity = 0 then
            exit(0);

        exit(CostAmount / Quantity);
    end;

    var
        HeaderType: Option Blank,Item,"Item Category","MO wise";
        HeaderValue: Code[100];
        HeaderDateFilter: Text[250];
        ItemCategoryCode: Code[20];
        ActualCost: Decimal;
        UnitCost: Decimal;
}

page 70003 "DFI ILE Consumption Subpage"
{
    Caption = 'Consumption Item Ledger Entries';
    PageType = List;
    UsageCategory = None;
    SourceTable = "Item Ledger Entry";
    SourceTableTemporary = true;
    ApplicationArea = All;
    Editable = false;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;

    layout
    {
        area(Content)
        {
            group(FilterInfo)
            {
                Caption = 'Filters';

                field(Type; HeaderType)
                {
                    ApplicationArea = All;
                    Caption = 'Type';
                    Editable = false;
                    ToolTip = 'Specifies the header Type filter used to fetch output entries and related consumption entries.';
                }
                field(Value; HeaderValue)
                {
                    ApplicationArea = All;
                    Caption = 'Value';
                    Editable = false;
                    ToolTip = 'Specifies the header Value filter used to fetch output entries and related consumption entries.';
                }
            }

            repeater(Lines)
            {
                Editable = false;

                field("Entry No."; Rec."Entry No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the entry number of the consumption item ledger entry.';
                }
                field("Posting Date"; Rec."Posting Date")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the posting date of the consumption item ledger entry.';
                }
                field("Item No."; Rec."Item No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the item number of the consumption item ledger entry.';
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the description of the consumption item ledger entry.';
                }
                field("Location Code"; Rec."Location Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the location code of the consumption item ledger entry.';
                }
                field("Lot No."; Rec."Lot No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the lot number of the consumption item ledger entry.';
                }
                field("Entry Type"; Rec."Entry Type")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the entry type. Only Consumption entries are shown.';
                }
                field("Document Type"; Rec."Document Type")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the document type of the consumption item ledger entry.';
                }
                field("Document No."; Rec."Document No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the document number of the consumption item ledger entry.';
                }
                field("Planning No."; Rec."Planning No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the planning number used to link the consumption entry with output entries.';
                }
                field("Order No."; Rec."Order No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the order number of the consumption item ledger entry.';
                }
                field(Quantity; Rec.Quantity)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the quantity of the consumption item ledger entry.';
                }
                field("Remaining Quantity"; Rec."Remaining Quantity")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the remaining quantity of the consumption item ledger entry.';
                }
                field("Actual Cost"; ActualCost)
                {
                    ApplicationArea = All;
                    Caption = 'Actual Cost';
                    AutoFormatType = 1;
                    ToolTip = 'Specifies the actual cost calculated from Value Entry for this consumption item ledger entry.';
                }
                field("Unit Cost"; UnitCost)
                {
                    ApplicationArea = All;
                    Caption = 'Unit Cost';
                    AutoFormatType = 1;
                    ToolTip = 'Specifies the unit cost calculated as Actual Cost divided by Quantity.';
                }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(OpenOutputEntries)
            {
                ApplicationArea = All;
                Caption = 'Output Item Ledger Entries';
                Image = ItemLedger;
                ToolTip = 'Open the Output Item Ledger Entries page for the current Type, Value and Date Filter.';

                trigger OnAction()
                var
                    OutputItemLedgerEntries: Page "DFI ILE Lines Subpage";
                begin
                    OutputItemLedgerEntries.LoadLines(HeaderType, HeaderValue, HeaderDateFilter);
                    OutputItemLedgerEntries.RunModal();
                end;
            }
        }
    }

    trigger OnAfterGetRecord()
    begin
        ActualCost := CalcActualCost(Rec."Entry No.");
        UnitCost := CalcUnitCost(ActualCost, Rec.Quantity);
    end;

    procedure LoadConsumptionLines(FilterType: Option Blank,Item,"Item Category","MO wise"; FilterValue: Code[100]; DateFilter: Text[250])
    var
        OutputItemLedgerEntry: Record "Item Ledger Entry";
        Item: Record Item;
        PlanningNoList: List of [Code[20]];
        PlanningNo: Code[20];
    begin
        HeaderType := FilterType;
        HeaderValue := FilterValue;
        HeaderDateFilter := DateFilter;

        Rec.Reset();
        Rec.DeleteAll();

        if not HasValidFilter(FilterType, FilterValue, DateFilter) then begin
            CurrPage.Update(false);
            exit;
        end;

        OutputItemLedgerEntry.Reset();
        OutputItemLedgerEntry.SetRange("Entry Type", OutputItemLedgerEntry."Entry Type"::Output);

        if DateFilter <> '' then
            OutputItemLedgerEntry.SetFilter("Posting Date", DateFilter);

        case FilterType of
            FilterType::Blank:
                AddPlanningNosFromOutput(OutputItemLedgerEntry, PlanningNoList);
            FilterType::Item:
                begin
                    if FilterValue = '' then begin
                        CurrPage.Update(false);
                        exit;
                    end;

                    OutputItemLedgerEntry.SetRange("Item No.", FilterValue);
                    AddPlanningNosFromOutput(OutputItemLedgerEntry, PlanningNoList);
                end;
            FilterType::"Item Category":
                begin
                    if FilterValue = '' then begin
                        CurrPage.Update(false);
                        exit;
                    end;

                    Item.SetRange("Item Category Code", FilterValue);
                    if Item.FindSet() then
                        repeat
                            OutputItemLedgerEntry.SetRange("Item No.", Item."No.");
                            AddPlanningNosFromOutput(OutputItemLedgerEntry, PlanningNoList);
                        until Item.Next() = 0;
                end;
            FilterType::"MO wise":
                begin
                    if FilterValue = '' then begin
                        CurrPage.Update(false);
                        exit;
                    end;

                    GetPlanningNosFromMO(FilterValue, PlanningNoList);
                end;
        end;

        foreach PlanningNo in PlanningNoList do
            InsertConsumptionEntriesByPlanningNo(PlanningNo, DateFilter);

        Rec.SetCurrentKey("Posting Date");
        CurrPage.Update(false);
    end;


    local procedure GetPlanningNosFromMO(MONo: Code[100]; var PlanningNoList: List of [Code[20]])
    var
        MOLine: Record "Mo Line";
    begin
        if MONo = '' then
            exit;

        MOLine.SetRange("Document No.", MONo);
        if MOLine.FindSet() then
            repeat
                if MOLine."Planning No" <> '' then
                    if not PlanningNoList.Contains(MOLine."Planning No") then
                        PlanningNoList.Add(MOLine."Planning No");
            until MOLine.Next() = 0;
    end;

    local procedure HasValidFilter(FilterType: Option Blank,Item,"Item Category","MO wise"; FilterValue: Code[100]; DateFilter: Text[250]): Boolean
    begin
        if DateFilter <> '' then
            exit(true);

        if (FilterType <> FilterType::Blank) and (FilterValue <> '') then
            exit(true);

        exit(false);
    end;

    local procedure AddPlanningNosFromOutput(var OutputItemLedgerEntry: Record "Item Ledger Entry"; var PlanningNoList: List of [Code[20]])
    begin
        if OutputItemLedgerEntry.FindSet() then
            repeat
                if OutputItemLedgerEntry."Planning No." <> '' then
                    if not PlanningNoList.Contains(OutputItemLedgerEntry."Planning No.") then
                        PlanningNoList.Add(OutputItemLedgerEntry."Planning No.");
            until OutputItemLedgerEntry.Next() = 0;
    end;

    local procedure InsertConsumptionEntriesByPlanningNo(PlanningNo: Code[20]; DateFilter: Text[250])
    var
        ConsumptionItemLedgerEntry: Record "Item Ledger Entry";
    begin
        ConsumptionItemLedgerEntry.Reset();
        ConsumptionItemLedgerEntry.SetRange("Entry Type", ConsumptionItemLedgerEntry."Entry Type"::Consumption);
        ConsumptionItemLedgerEntry.SetRange("Planning No.", PlanningNo);

        if DateFilter <> '' then
            ConsumptionItemLedgerEntry.SetFilter("Posting Date", DateFilter);

        if ConsumptionItemLedgerEntry.FindSet() then
            repeat
                if not Rec.Get(ConsumptionItemLedgerEntry."Entry No.") then begin
                    Rec.Init();
                    Rec := ConsumptionItemLedgerEntry;
                    Rec.Insert();
                end;
            until ConsumptionItemLedgerEntry.Next() = 0;
    end;

    local procedure CalcActualCost(ItemLedgerEntryNo: Integer): Decimal
    var
        ValueEntry: Record "Value Entry";
        CostAmountActual: Decimal;
    begin
        Clear(CostAmountActual);

        if ItemLedgerEntryNo = 0 then
            exit(0);

        ValueEntry.SetRange("Item Ledger Entry No.", ItemLedgerEntryNo);
        if ValueEntry.FindSet() then
            repeat
                CostAmountActual += ValueEntry."Cost Amount (Actual)";
            until ValueEntry.Next() = 0;

        exit(CostAmountActual);
    end;

    local procedure CalcUnitCost(CostAmount: Decimal; Quantity: Decimal): Decimal
    begin
        if Quantity = 0 then
            exit(0);

        exit(CostAmount / Quantity);
    end;

    var
        HeaderType: Option Blank,Item,"Item Category","MO wise";
        HeaderValue: Code[100];
        HeaderDateFilter: Text[250];
        ActualCost: Decimal;
        UnitCost: Decimal;
}

page 70000 "DFI Type Value Document"
{
    Caption = 'Type Value Document';
    PageType = Document;
    SourceTable = "DFI Type Value Header";
    SourceTableView = where("Primary Key" = const('DEFAULT'));
    ApplicationArea = All;
    UsageCategory = Tasks;
    InsertAllowed = false;
    DeleteAllowed = false;

    layout
    {
        area(Content)
        {
            group(General)
            {
                Caption = 'Header';

                field(Type; Rec.Type)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies whether the value will be selected item wise, item category wise, or MO wise. Leave blank to apply only the date filter.';

                    trigger OnValidate()
                    begin
                        Rec.Modify(true);
                        RefreshSubpages();
                        CurrPage.Update(false);
                    end;
                }

                field(Value; Rec.Value)
                {
                    ApplicationArea = All;
                    Lookup = true;
                    ToolTip = 'Specifies the selected value. If Type is Item, lookup opens Item List and saves the selected Item No. If Type is Item Category, lookup opens Item Categories and saves the selected category code.';

                    trigger OnLookup(var Text: Text): Boolean
                    begin
                        exit(LookupValue(Text));
                    end;

                    trigger OnValidate()
                    begin
                        Rec.Modify(true);
                        RefreshSubpages();
                        CurrPage.Update(false);
                    end;
                }

                field("Value Description"; Rec."Value Description")
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the description of the selected value.';
                }

                field("Date Filter"; Rec."Date Filter")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the posting date filter or date range, for example 01/04/2026..30/04/2026.';

                    trigger OnValidate()
                    begin
                        Rec.Modify(true);
                        RefreshSubpages();
                        CurrPage.Update(false);
                    end;
                }
            }

            part(ActualItemLedgerEntryTotals; "AC DFI ILE Totals Subpage")
            {
                ApplicationArea = All;
                Caption = 'Actual Output Entry Totals';
                Editable = false;
                SubPageLink = "Costing Type" = filter('Actual');
            }
            part(StandardTotals; "ST DFI ILE Totals Subpage")
            {
                ApplicationArea = All;
                Caption = 'Standard Output Entry Totals';
                Editable = false;
                SubPageLink = "Costing Type" = filter('Standard');
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(OpenOutputEntries)
            {
                ApplicationArea = All;
                Caption = 'Output Item Ledger Entries';
                Image = ItemLedger;
                ToolTip = 'Open the Output Item Ledger Entries page for the current Type, Value and Date Filter.';

                trigger OnAction()
                var
                    OutputItemLedgerEntries: Page "DFI ILE Lines Subpage";
                begin
                    OutputItemLedgerEntries.LoadLines(Rec.Type, Rec.Value, Rec."Date Filter");
                    OutputItemLedgerEntries.RunModal();
                end;
            }

            action(OpenConsumptionEntries)
            {
                ApplicationArea = All;
                Caption = 'Consumption Item Ledger Entries';
                Image = ItemLedger;
                ToolTip = 'Open the Consumption Item Ledger Entries page for the current Type, Value and Date Filter.';

                trigger OnAction()
                var
                    ConsumptionItemLedgerEntries: Page "DFI ILE Consumption Subpage";
                begin
                    ConsumptionItemLedgerEntries.LoadConsumptionLines(Rec.Type, Rec.Value, Rec."Date Filter");
                    ConsumptionItemLedgerEntries.RunModal();
                end;
            }
            action("Generate DFI Costing")
            {
                ApplicationArea = All;
                Caption = 'Generate DFI Costing';
                Image = Calculate;

                trigger OnAction()
                var
                    CostingMgt: Codeunit "DFI Costing To Entry Total";
                begin
                    Rec.TestField(rec.Value);
                    CostingMgt.GenerateCostingFromStyleItem(Rec.Value);
                    Message('DFI costing generated for Item No. %1', Rec.Value);
                end;
            }

        }
    }

    trigger OnOpenPage()
    begin
        EnsureHeaderExists();
        Rec.Get(Rec.GetDefaultPrimaryKey());
        ClearHeaderFiltersOnOpen();
    end;

    trigger OnAfterGetCurrRecord()
    begin
        RefreshSubpages();
    end;

    local procedure ClearHeaderFiltersOnOpen()
    begin
        Rec.Type := Rec.Type::Blank;
        Clear(Rec.Value);
        Clear(Rec."Value Description");
        Clear(Rec."Date Filter");
        Rec.Modify(true);
        RefreshSubpages();
    end;

    local procedure EnsureHeaderExists()
    var
        TypeValueHeader: Record "DFI Type Value Header";
    begin
        if not TypeValueHeader.Get(TypeValueHeader.GetDefaultPrimaryKey()) then begin
            TypeValueHeader.Init();
            TypeValueHeader."Primary Key" := TypeValueHeader.GetDefaultPrimaryKey();
            TypeValueHeader.Type := TypeValueHeader.Type::Blank;
            TypeValueHeader.Insert(true);
        end;
    end;

    local procedure LookupValue(var Text: Text): Boolean
    var
        Item: Record Item;
        ItemCategory: Record "Item Category";
        MarketingOrder: Record "Marketing Order";
        ItemList: Page "Item List";
        ItemCategories: Page "Item Categories";
        MOList: Page "MO List";
    begin
        EnsureHeaderExists();

        case Rec.Type of
            Rec.Type::Blank:
                begin
                    Message('Please select Type before selecting Value.');
                    exit(false);
                end;
            Rec.Type::Item:
                begin
                    Clear(Item);
                    Clear(ItemList);
                    Item.SetRange("Item Category Code", 'FG');
                    ItemList.SetTableView(Item);
                    ItemList.LookupMode(true);

                    if Rec.Value <> '' then
                        if Item.Get(Rec.Value) then
                            ItemList.SetRecord(Item);

                    if ItemList.RunModal() = Action::LookupOK then begin
                        ItemList.GetRecord(Item);
                        Rec.Validate(Value, Item."No.");
                        Rec.Modify(true);
                        Text := Rec.Value;
                        RefreshSubpages();
                        CurrPage.Update(false);
                        exit(true);
                    end;
                end;
            Rec.Type::"Item Category":
                begin
                    Clear(ItemCategory);
                    Clear(ItemCategories);
                    ItemCategories.LookupMode(true);

                    if Rec.Value <> '' then
                        if ItemCategory.Get(Rec.Value) then
                            ItemCategories.SetRecord(ItemCategory);

                    if ItemCategories.RunModal() = Action::LookupOK then begin
                        ItemCategories.GetRecord(ItemCategory);
                        Rec.Validate(Value, ItemCategory.Code);
                        Rec.Modify(true);
                        Text := Rec.Value;
                        RefreshSubpages();
                        CurrPage.Update(false);
                        exit(true);
                    end;
                end;
            Rec.Type::"MO wise":
                begin
                    Clear(MarketingOrder);
                    Clear(MOList);
                    MarketingOrder.SetRange(Status, MarketingOrder.Status::Released);
                    MOList.SetTableView(MarketingOrder);
                    MOList.LookupMode(true);

                    if Rec.Value <> '' then
                        if MarketingOrder.Get(Rec.Value) then
                            MOList.SetRecord(MarketingOrder);

                    if MOList.RunModal() = Action::LookupOK then begin
                        MOList.GetRecord(MarketingOrder);
                        Rec.Validate(Value, MarketingOrder."No.");
                        Rec.Modify(true);
                        Text := Rec.Value;
                        RefreshSubpages();
                        CurrPage.Update(false);
                        exit(true);
                    end;
                end;
        end;

        exit(false);
    end;

    local procedure RefreshSubpages()
    begin
        CurrPage.ActualItemLedgerEntryTotals.Page.LoadTotals(Rec.Type, Rec.Value, Rec."Date Filter");
        CurrPage.StandardTotals.Page.LoadTotals(Rec.Type, rec.Value, rec."Date Filter");
    end;
}

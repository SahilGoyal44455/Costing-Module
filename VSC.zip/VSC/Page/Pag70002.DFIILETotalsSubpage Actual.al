page 70002 "AC DFI ILE Totals Subpage"
{
    Caption = 'Actual Output Entry Totals';
    PageType = ListPart;
    SourceTable = "DFI ILE Entry Total";
    ApplicationArea = All;
    Editable = false;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    layout
    {
        area(Content)
        {
            repeater(Totals)
            {
                Editable = false;

                field("Costing Type"; Rec."Costing Type")
                {
                    ApplicationArea = All;
                }
                field("Total Entry Type"; Rec."Total Entry Type")
                {
                    ApplicationArea = All;
                    Caption = 'Total Entry Type';
                    ToolTip = 'Specifies whether this row is the total of Output entries or Consumption entries.';
                }
                field(Type; Rec.Type)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the selected header type used when totals were calculated.';
                }
                field(Value; Rec.Value)
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the selected header value used when totals were calculated.';
                }
                field("Item No."; Rec."Item No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the item number for which totals are shown.';
                }
                field("Process Type"; Rec."Process Type")
                {
                    ApplicationArea = All;
                }
                field("Style Item No."; Rec."Style Item No.")
                {
                    ApplicationArea = All;
                }
                field("Style No."; Rec."Style No.")
                {
                    ApplicationArea = All;
                }
                field("Total Quantity"; Rec."Total Quantity")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the total quantity grouped item-wise.';
                }
                field("Total Amount"; Rec."Total Amount")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the total actual cost calculated from Value Entry.';
                }
                field("Unit Cost"; Rec."Unit Cost")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies the unit cost calculated as Total Amount divided by Total Quantity.';
                }
            }
        }
    }

    procedure LoadTotals(FilterType: Option Blank,Item,"Item Category","MO wise"; FilterValue: Code[100]; DateFilter: Text[250])
    var
        OutputItemLedgerEntry: Record "Item Ledger Entry";
        Item: Record Item;
        PlanningNoList: List of [Code[20]];
        PlanningNo: Code[20];
    begin
        Rec.Reset();
        Rec.DeleteAll();

        if not HasValidFilter(FilterType, FilterValue, DateFilter) then begin
            CurrPage.Update(false);
            exit;
        end;

        OutputItemLedgerEntry.Reset();
        OutputItemLedgerEntry.SetRange("Entry Type", OutputItemLedgerEntry."Entry Type"::Output);

        if DateFilter <> '' then
            OutputItemLedgerEntry.SetFilter("Posting Date", DateFilter);

        case FilterType of
            FilterType::Blank:
                InsertOutputTotalsAndPlanningNos(OutputItemLedgerEntry, FilterType, FilterValue, PlanningNoList);
            FilterType::Item:
                begin
                    if FilterValue = '' then begin
                        CurrPage.Update(false);
                        exit;
                    end;

                    OutputItemLedgerEntry.SetRange("Item No.", FilterValue);
                    InsertOutputTotalsAndPlanningNos(OutputItemLedgerEntry, FilterType, FilterValue, PlanningNoList);
                end;
            FilterType::"Item Category":
                begin
                    if FilterValue = '' then begin
                        CurrPage.Update(false);
                        exit;
                    end;

                    Item.SetRange("Item Category Code", FilterValue);
                    if Item.FindSet() then
                        repeat
                            OutputItemLedgerEntry.SetRange("Item No.", Item."No.");
                            InsertOutputTotalsAndPlanningNos(OutputItemLedgerEntry, FilterType, FilterValue, PlanningNoList);
                        until Item.Next() = 0;
                end;
            FilterType::"MO wise":
                begin
                    if FilterValue = '' then begin
                        CurrPage.Update(false);
                        exit;
                    end;

                    GetPlanningNosFromMO(FilterValue, PlanningNoList);
                    foreach PlanningNo in PlanningNoList do
                        InsertOutputTotalsByPlanningNo(PlanningNo, FilterType, FilterValue, DateFilter);
                end;
        end;

        foreach PlanningNo in PlanningNoList do
            InsertConsumptionTotalsByPlanningNo(PlanningNo, FilterType, FilterValue, DateFilter);

        UpdateUnitCostOnTotals();
        CurrPage.Update(false);
    end;


    local procedure GetPlanningNosFromMO(MONo: Code[100]; var PlanningNoList: List of [Code[20]])
    var
        MOLine: Record "Mo Line";
    begin
        if MONo = '' then
            exit;

        MOLine.SetRange("Document No.", MONo);
        if MOLine.FindSet() then
            repeat
                if MOLine."Planning No" <> '' then
                    if not PlanningNoList.Contains(MOLine."Planning No") then
                        PlanningNoList.Add(MOLine."Planning No");
            until MOLine.Next() = 0;
    end;

    local procedure InsertOutputTotalsByPlanningNo(PlanningNo: Code[20]; FilterType: Option Blank,Item,"Item Category","MO wise"; FilterValue: Code[100]; DateFilter: Text[250])
    var
        OutputItemLedgerEntry: Record "Item Ledger Entry";
        CostingType: Option "Standard","Actual";
    begin
        OutputItemLedgerEntry.Reset();
        OutputItemLedgerEntry.SetRange("Entry Type", OutputItemLedgerEntry."Entry Type"::Output);
        OutputItemLedgerEntry.SetRange("Planning No.", PlanningNo);

        if DateFilter <> '' then
            OutputItemLedgerEntry.SetFilter("Posting Date", DateFilter);

        if OutputItemLedgerEntry.FindSet() then
            repeat
                InsertOrUpdateTotal(CostingType::Actual, OutputItemLedgerEntry, FilterType, FilterValue, Rec."Total Entry Type"::Output);
            until OutputItemLedgerEntry.Next() = 0;
    end;

    local procedure HasValidFilter(FilterType: Option Blank,Item,"Item Category","MO wise"; FilterValue: Code[100]; DateFilter: Text[250]): Boolean
    begin
        if DateFilter <> '' then
            exit(true);

        if (FilterType <> FilterType::Blank) and (FilterValue <> '') then
            exit(true);

        exit(false);
    end;

    local procedure InsertOutputTotalsAndPlanningNos(var OutputItemLedgerEntry: Record "Item Ledger Entry"; FilterType: Option Blank,Item,"Item Category","MO wise"; FilterValue: Code[100]; var PlanningNoList: List of [Code[20]])
 CostingType: Option "Standard","Actual";
    begin
        if OutputItemLedgerEntry.FindSet() then
            repeat
                InsertOrUpdateTotal(CostingType::Actual, OutputItemLedgerEntry, FilterType, FilterValue, Rec."Total Entry Type"::Output);

                if OutputItemLedgerEntry."Planning No." <> '' then
                    if not PlanningNoList.Contains(OutputItemLedgerEntry."Planning No.") then
                        PlanningNoList.Add(OutputItemLedgerEntry."Planning No.");
            until OutputItemLedgerEntry.Next() = 0;
    end;

    local procedure InsertConsumptionTotalsByPlanningNo(PlanningNo: Code[20]; FilterType: Option Blank,Item,"Item Category","MO wise"; FilterValue: Code[100]; DateFilter: Text[250])
    var
        ConsumptionItemLedgerEntry: Record "Item Ledger Entry";
        CostingType: Option "Standard","Actual";
    begin
        ConsumptionItemLedgerEntry.Reset();
        ConsumptionItemLedgerEntry.SetRange("Entry Type", ConsumptionItemLedgerEntry."Entry Type"::Consumption);
        ConsumptionItemLedgerEntry.SetRange("Planning No.", PlanningNo);

        if DateFilter <> '' then
            ConsumptionItemLedgerEntry.SetFilter("Posting Date", DateFilter);

        if ConsumptionItemLedgerEntry.FindSet() then
            repeat
                InsertOrUpdateTotal(CostingType::Actual, ConsumptionItemLedgerEntry, FilterType, FilterValue, Rec."Total Entry Type"::Consumption);
            until ConsumptionItemLedgerEntry.Next() = 0;
    end;

    local procedure InsertOrUpdateTotal(CostingType: Option "Standard","Actual"; ItemLedgerEntry: Record "Item Ledger Entry"; FilterType: Option Blank,Item,"Item Category","MO wise"; FilterValue: Code[100]; TotalEntryType: Option Output,Consumption)
    var
        EntryTotal: Record "DFI ILE Entry Total";
    begin
        if EntryTotal.Get(CostingType, TotalEntryType, FilterType, FilterValue, ItemLedgerEntry."Item No.") then begin
            EntryTotal."Total Quantity" += ItemLedgerEntry.Quantity;
            EntryTotal."Total Amount" += CalcActualCost(ItemLedgerEntry."Entry No.");
            EntryTotal.Modify(true);
        end else begin
            EntryTotal.Init();
            EntryTotal."Costing Type" := EntryTotal."Costing Type"::Actual;
            EntryTotal."Total Entry Type" := TotalEntryType;
            EntryTotal.Type := FilterType;
            EntryTotal.Value := FilterValue;
            EntryTotal."Item No." := ItemLedgerEntry."Item No.";
            EntryTotal."Total Quantity" := ItemLedgerEntry.Quantity;
            EntryTotal."Total Amount" := CalcActualCost(ItemLedgerEntry."Entry No.");
            EntryTotal.Insert(true);
        end;
    end;

    local procedure UpdateUnitCostOnTotals()
    var
        EntryTotal: Record "DFI ILE Entry Total";
    begin
        if EntryTotal.FindSet(true) then
            repeat
                if EntryTotal."Total Quantity" = 0 then
                    EntryTotal."Unit Cost" := 0
                else
                    EntryTotal."Unit Cost" := EntryTotal."Total Amount" / EntryTotal."Total Quantity";
                EntryTotal.Modify(true);
            until EntryTotal.Next() = 0;
    end;

    local procedure CalcActualCost(ItemLedgerEntryNo: Integer): Decimal
    var
        ValueEntry: Record "Value Entry";
        CostAmountActual: Decimal;
    begin
        Clear(CostAmountActual);

        if ItemLedgerEntryNo = 0 then
            exit(0);

        ValueEntry.SetRange("Item Ledger Entry No.", ItemLedgerEntryNo);
        if ValueEntry.FindSet() then
            repeat
                CostAmountActual += ValueEntry."Cost Amount (Actual)";
            until ValueEntry.Next() = 0;

        exit(CostAmountActual);
    end;
}

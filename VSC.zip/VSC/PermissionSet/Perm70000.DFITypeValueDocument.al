permissionset 70000 "DFI Type Value Doc"
{
    Assignable = true;
    Caption = 'DFI Type Value Document';
    Permissions =
        tabledata "DFI Type Value Header" = RIMD,
        table "DFI Type Value Header" = X,
        tabledata "DFI ILE Entry Total" = RIMD,
        table "DFI ILE Entry Total" = X,
        tabledata "Item Ledger Entry" = R,
        table "Item Ledger Entry" = X,
        tabledata "Value Entry" = R,
        table "Value Entry" = X,
        tabledata "Marketing Order" = R,
        table "Marketing Order" = X,
        tabledata "Mo Line" = R,
        table "Mo Line" = X,
        page "DFI Type Value Document" = X,
        page "DFI ILE Lines Subpage" = X,
       page "ST DFI ILE Totals Subpage" = X,
        page "AC DFI ILE Totals Subpage" = X,
        page "DFI ILE Consumption Subpage" = X,
        page "MO List" = X;
}

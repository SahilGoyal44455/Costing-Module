table 70000 "DFI Type Value Header"
{
    Caption = 'DFI Type Value Header';
    DataClassification = CustomerContent;
    LookupPageId = "DFI Type Value Document";
    DrillDownPageId = "DFI Type Value Document";

    fields
    {
        field(1; "Primary Key"; Code[20])
        {
            Caption = 'Primary Key';
            DataClassification = SystemMetadata;
        }
        field(2; Type; Option)
        {
            Caption = 'Type';
            OptionMembers = Blank,Item,"Item Category","MO wise";
            OptionCaption = ' ,Item,Item Category,MO wise';
            InitValue = Blank;
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                if Type <> xRec.Type then begin
                    Clear(Value);
                    Clear("Value Description");
                end;
            end;
        }
        field(3; Value; Code[100])
        {
            Caption = 'Value';
            DataClassification = CustomerContent;
            TableRelation = if (Type = const(Item)) Item."No." where("Item Category Code" = const('FG'))
                            else if (Type = const("Item Category")) "Item Category".Code
                            else if (Type = const("MO wise")) "Marketing Order"."No." where(Status = const(Released));
            ValidateTableRelation = false;

            trigger OnValidate()
            begin
                ValidateValue();
                UpdateValueDescription();
            end;
        }
        field(4; "Value Description"; Text[100])
        {
            Caption = 'Value Description';
            DataClassification = CustomerContent;
            Editable = false;
        }
        field(5; "Date Filter"; Text[250])
        {
            Caption = 'Date Filter';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                ValidateDateFilter();
            end;
        }
    }

    keys
    {
        key(PK; "Primary Key")
        {
            Clustered = true;
        }
    }

    trigger OnInsert()
    begin
        if "Primary Key" = '' then
            "Primary Key" := GetDefaultPrimaryKey();
    end;

    procedure GetDefaultPrimaryKey(): Code[20]
    begin
        exit('DEFAULT');
    end;

    procedure ValidateValue()
    var
        Item: Record Item;
        ItemCategory: Record "Item Category";
        MarketingOrder: Record "Marketing Order";
    begin
        if Value = '' then
            exit;

        case Type of
            Type::Blank:
                Error('Please select Type before entering Value.');
            Type::Item:
                begin
                    if not Item.Get(Value) then
                        Error('Item No. %1 does not exist.', Value);

                    if Item."Item Category Code" <> 'FG' then
                        Error('Only FG item category items are allowed. Item No. %1 has Item Category Code %2.', Value, Item."Item Category Code");
                end;
            Type::"Item Category":
                if not ItemCategory.Get(Value) then
                    Error('Item Category %1 does not exist.', Value);
            Type::"MO wise":
                begin
                    if not MarketingOrder.Get(Value) then
                        Error('Marketing Order %1 does not exist.', Value);

                    if MarketingOrder.Status <> MarketingOrder.Status::Released then
                        Error('Only Released Marketing Orders are allowed. Marketing Order %1 is %2.', Value, MarketingOrder.Status);
                end;
        end;
    end;

    procedure UpdateValueDescription()
    var
        Item: Record Item;
        ItemCategory: Record "Item Category";
        MarketingOrder: Record "Marketing Order";
    begin
        Clear("Value Description");

        if Value = '' then
            exit;

        case Type of
            Type::Item:
                if Item.Get(Value) then
                    "Value Description" := CopyStr(Item.Description, 1, MaxStrLen("Value Description"));
            Type::"Item Category":
                if ItemCategory.Get(Value) then
                    "Value Description" := CopyStr(ItemCategory.Description, 1, MaxStrLen("Value Description"));
            Type::"MO wise":
                if MarketingOrder.Get(Value) then
                    "Value Description" := CopyStr(MarketingOrder."Sell-to Customer Name", 1, MaxStrLen("Value Description"));
        end;
    end;

    procedure ValidateDateFilter()
    var
        ItemLedgerEntry: Record "Item Ledger Entry";
    begin
        if "Date Filter" = '' then
            exit;

        ItemLedgerEntry.SetFilter("Posting Date", "Date Filter");
    end;
}

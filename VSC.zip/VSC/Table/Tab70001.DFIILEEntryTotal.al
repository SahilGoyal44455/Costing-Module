table 70001 "DFI ILE Entry Total"
{
    Caption = 'DFI ILE Entry Total';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Item No."; Code[20])
        {
            Caption = 'Item No.';
            DataClassification = CustomerContent;
            TableRelation = Item."No.";
        }
        field(2; Type; Option)
        {
            Caption = 'Type';
            OptionMembers = Blank,Item,"Item Category","MO wise";
            OptionCaption = ' ,Item,Item Category,MO wise';
            DataClassification = CustomerContent;
        }
        field(3; "Total Quantity"; Decimal)
        {
            Caption = 'Total Quantity';
            DataClassification = CustomerContent;
            DecimalPlaces = 0 : 5;
        }
        field(4; "Total Amount"; Decimal)
        {
            Caption = 'Total Amount';
            DataClassification = CustomerContent;
            AutoFormatType = 1;
        }
        field(5; "Total Entry Type"; Option)
        {
            Caption = 'Total Entry Type';
            OptionMembers = Output,Consumption;
            OptionCaption = 'Output,Consumption';
            DataClassification = CustomerContent;
        }
        field(6; Value; Code[100])
        {
            Caption = 'Value';
            DataClassification = CustomerContent;
        }
        field(7; "Unit Cost"; Decimal)
        {
            Caption = 'Unit Cost';
            DataClassification = CustomerContent;
            AutoFormatType = 1;
        }
        field(8; "Costing Type"; Option)
        {
            Caption = 'Costing Type';
            OptionMembers = Standard,Actual;
        }
        field(10; "Process Type"; Code[20])
        {
            Caption = 'Process Type';
        }
        field(12; "Style Item No."; Code[20])
        {
            Caption = 'Style Item No.';
        }
        field(13; "Style No."; Code[20])
        {
            Caption = 'Style No.';
        }
    }

    keys
    {
        key(PK; "Costing Type", "Total Entry Type", Type, Value, "Item No.")
        {
            Clustered = true;
        }
    }
}